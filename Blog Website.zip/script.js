document.querySelectorAll(".comments button").forEach(button => {
    button.addEventListener("click", () => {
        const comments = button.parentElement;
        const nameInput = comments.querySelector(".name");
        const textArea = comments.querySelector("textarea");
        const list = comments.querySelector(".comment-list");

        const name = nameInput.value.trim();
        const text = textArea.value.trim();

        if (!name || !text) {
            alert("Please enter your name and comment.");
            return;
        }

        const comment = document.createElement("div");
        comment.className = "comment";
        comment.innerHTML = `<strong>${name}</strong><br>${text}`;

        list.appendChild(comment);

        nameInput.value = "";
        textArea.value = "";
    });
});
